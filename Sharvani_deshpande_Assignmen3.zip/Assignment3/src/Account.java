import java.util.Calendar;
import java.util.Date;

/**
 	Name : Sharvani Deshpande
	Programming Assignment 3
	Solution for Problem 9.7
	Submitted for CS585C, Fall 2016
	Due Date: 10/28/2016 */
/**
 * @author SHARVANI DESHPANDE
 * This class is used to create the account class and its members and methods so that we can use it whenever required.
 *`It defines getters and setters for all the variables declared
 */
public class Account 
{
	public static final int DEFAULT=0;
	//variable declarations
	private int id;
	private double balance;
	private double annualInterestRate;
	private Date dateCreated;
	//variables for monthlyInterest and monthlyInterestRate
	private double monthlyInterest=DEFAULT;
	private double monthlyInterestRate=DEFAULT;
	//constructor which intialises default account
	Account()
	{
		this.id=DEFAULT;
		this.balance=DEFAULT;
		this.annualInterestRate=DEFAULT;
		this.dateCreated=new Date();
	}
	//Constructor which creates account with specified id and initial balance
	/**
	 * @param id
	 * @param balance
	 */
	public Account(int id, double balance) 
	{
		
		this.id = id;
		this.balance = balance;
	}
	//getter method to return the id
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	//setter method which intialises the id value to the parameter passed
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	//getter method to return the balance
	/**
	 * @return the balance
	 */
	public double getBalance() {
		return balance;
	}
	//setter method to set the balance which is passed as a parameter to this method
	/**
	 * @param balance the balance to set
	 */
	public void setBalance(double balance) {
		this.balance = balance;
	}
	//getter method which returns the annualInterestRate
	/**
	 * @return the annualInterestRate
	 */
	public double getAnnualInterestRate() {
		return annualInterestRate;
	}
	//setter method which to assign a value to the annualInterestRate that is passed as a parameter to this method
	/**
	 * @param annualInterestRate the annualInterestRate to set
	 */
	public void setAnnualInterestRate(double annualInterestRate) {
		this.annualInterestRate = annualInterestRate;
	}
	//getter method which returns the dateCreated
	/**
	 * @return the dateCreated
	 */
	public Date getDateCreated() {
		return dateCreated;
	}
	
	//getter method which returns the monthlyInterest
	/**
	 * @return the monthlyInterest
	 */
	public double getMonthlyInterest() 
	{
		monthlyInterest= (getBalance()*getMonthlyInterestRate())/100;
		return monthlyInterest;
	}
	//setter Method which calculates the monthlyInterest
	/**
	 * @param monthlyInterest the monthlyInterest to set
	 */
	public void setMonthlyInterest(double monthlyInterest) 
	{
		this.monthlyInterest= monthlyInterest;
	}
	//getter method to return the monthlyInterestRate
	/**
	 * @return the monthlyInterestRate
	 */
	public double getMonthlyInterestRate() 
	{
		monthlyInterestRate=getAnnualInterestRate()/12.0;
		return monthlyInterestRate;
	}
	//setter method which calculates the monhtlyInterestRate
	/**
	 * @param monthlyInterestRate the monthlyInterestRate to set
	 */
	public void setMonthlyInterestRate(double monthlyInterestRate) {
		this.monthlyInterestRate = monthlyInterestRate;
	}
	//This method is used whenever user performs a withdraw or if the user withdraws some amount from the account
	/**
	 * 
	 * @param bal
	 */
	public void withdraw(double bal)
	{
		setBalance((getBalance()-bal));
	}
	//This method is used whenever user performs a deposit or if the user deposits some amount from the account
	/**
	 * 
	 * @param bal
	 */
	public void deposit(double bal)
	{
		setBalance((getBalance()+bal));
	}
	//main method to intialise object values and invoke methods of Account class
	public static void main(String args[])
	{
		//create account object by passing id and account balance as a parameter
		Account a = new Account(1122,20000);
		//sets the annualInterestRate ,withdraws 2500 and deposit 3000
		a.setAnnualInterestRate(4.5);
		a.withdraw(2500);
		a.deposit(3000);
		//sets the date to current date
		Date d=new Date();
		Calendar currentDate = Calendar.getInstance();
		a.dateCreated=(currentDate.getTime());
		//printing the details
		System.out.println("Account Details are:");
		System.out.println("Balance is "+a.getBalance());
		System.out.println("Monthly Interest is"+a.getMonthlyInterest());
		System.out.println("Date when account is created is "+a.getDateCreated());
	}
	
}
/*
 =======================
 Output:
 =======================
 Account Details are:
Balance is 20500.0
Monthly Interest is76.875
Date when account is created is Sat Oct 29 22:38:23 EDT 2016

 * 
 * */
