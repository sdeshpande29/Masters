import java.util.Scanner;



/**
 	Name : Sharvani Deshpande
	Programming Assignment 3
	Solution for Problem 10.3
	Submitted for CS585C, Fall 2016
	Due Date: 10/28/2016 */
/**
 * @author SHARVANI DESHPANDE
 * This class is used to create the MyInteger class and its members and methods so that we can use it whenever required.
 *`It defines getters and setters for all the variables declared
 */
 public class MyInteger 
 
{
	 
	 //variables declaration;
	 private int value;
	 //constructor which takes val as a parameter
	 /**
	  * 
	  * @param val
	  */
	MyInteger(int val)
	{
		this.value=val;
	}
	//getter method which returns the value
	public int getValue() 
	{
		return value;
	}
	//isEven method returns a true value if the number is even or else it returns false
	public boolean isEven()
	{
		if(value%2==0)return true;
			return false;
		
	}
	//isOdd method returns a true value if the number is odd or else it returns false
	public boolean isOdd()
	{
		if(value%2!=0)return true;
			return false;
		
	}
	// This method will return a value of true if the value passed is a prime number or else it will return false
	
	public boolean isPrime()
	{
		if(value<2)
		{
			return false;
		}
		if(value ==2)
		{
			return true;
		}
		for(int i=2;i<=value/2;i++)
		{
			int temp;
			temp=value%i;
			if(temp==0)
			{
				return false;
				
			}
			
		}
		return true;
	}
	//isEven takes the value as a parameter and hence returns true if the value is even or else it will return false
	
	public boolean isEven(int value)
	{
		if(value%2==0)return true;
		return false;
	}
	//isOdd takes the value as a parameter and hence returns true if the value is even or else it will return false
	
	public  boolean isOdd(int value)
	{
		if(value %2!=0)return true;
		return false;
	}
	//isPrime is a static method which returns true if a number is prime or else it will return false
	public static boolean isPrime(int value)
	{
		if(value<2)
		{
			return false;
		}
		if(value ==2)
		{
			return true;
		}
		for(int i=2;i<=value/2;i++)
		{
			int temp;
			temp=value%i;
			if(temp==0)
			{
				return false;
				
			}
			
		}
		return true;
	}	
	//static method to determine if a number is even
	public static boolean isEven(MyInteger m)
	{
		
	return m.isEven(m.getValue());
		
	}
	//static method to determine if a number is odd
	public static boolean isOdd(MyInteger m)
	{
		
		return m.isOdd(m.getValue());
		
	}
	//static method to determine if a number is prime by taking value as a parameter
	public static boolean isPrime(MyInteger m)
	{
		
		return m.isPrime(m.getValue());
		
	}
	//equals method checks the equality of two values one is defined as the value and other is passed as a parameter to the same method
	public boolean equals(int j)
	{
		
		return (value==j);
		
	}
	//equals method checks the equality of two values by taking the reference that is passed as a pararmeter
	public boolean equals(MyInteger m)
	{
		
		return equals(m.getValue());
		
	}
	//static method parseInt is defined to parse the string
	public static int parseInt(String t)
	{
		 
		return Integer.parseInt(t);
	}
	//Static method parseaInt is defined to parse array of characters
		public static int parseInt(char[] t)
	{
		
		return parseInt(new String(t));
	}
	//main method
	public static void main(String args[])
	{
		Scanner sb=new Scanner(System.in);
		//prompt the user to key in the input
		System.out.println("Enter any number of your choice");
		int number= sb.nextInt();
		if(number<0)
		{
			System.err.println("You cannot enter a negative number");
			System.exit(0);
		}
		/*the number which is entered by the user is passed as an argument to the constructor when we intialise the MyInteger object*/
		MyInteger m= new MyInteger(number);
		//checking the functionality of all the methods defined
		System.out.println("Number " +number+ " is prime  "+m.isPrime());
		System.out.println("Number " +number+ " is even " +m.isEven());
		System.out.println("Number " +number+ " is odd  " +m.isOdd());
		System.out.println("Number  21  is prime  " +MyInteger.isPrime(21));
		System.out.println("Number " +number+ " is odd  " +m.isOdd(m.getValue()));
		System.out.println("Number " +number+ " is even  " +m.isEven(m.getValue()));
		System.out.println("Number " +number+ " is prime  " +m.isPrime(m.getValue()));
		System.out.println("Number " +number+ " is equal to 45  " +m.equals(45));
		char[] pattern ={'5' , '7' , '0' , '9'};
		System.out.println("Characters  "+MyInteger.parseInt(pattern));
		String s="123456799";
		System.out.println("String after parsing is "+MyInteger.parseInt(s));
		
	}
}
 /*
  ===============
  Output:
  ===============
  Enter any number of your choice
31
Number 31 is prime  true
Number 31 is even false
Number 31 is odd  true
Number  21  is prime  false
Number 31 is odd  true
Number 31 is even  false
Number 31 is prime  true
Number 31 is equal to 45  false
Characters  5709
String after parsing is 123456799
  */

		
	
