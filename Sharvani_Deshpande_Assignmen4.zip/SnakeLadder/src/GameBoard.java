//this class declares methods used in the gameboard
public class GameBoard 
{
	//declaring constants
	private static final int NUM_ROWS = 10;
	private static final int NUM_COLS = 10;
	private static final int NUM_CELLS = NUM_ROWS * NUM_COLS;
	private static final int NUM_LADDERS = 5;
	private static final int NUM_SNAKES = 5;

	// 2-d array for the gameboard
	private Cell[][] matrix = new Cell[NUM_ROWS][NUM_COLS];
	private Player[] players;
	private int currPlayer = 0;

	//creating  dice instance
	private Dice dice = new Dice();

	// creating snakes and ladders
	private Ladder[] ladders;
	private Snake[] snakes;
	private int numPlayers;

	public GameBoard(int numPlayers) {
		this.numPlayers = numPlayers;

		// create an array of players
		players = new Player[numPlayers];
		for (int num = 0; num < players.length; ++num) {
			players[num] = new Player("A" + num);
		}

		// create the board (2-d array of Cell)
		for (int cellNum = 1; cellNum <= 100; cellNum++) {
			int val = NUM_CELLS - cellNum;
			int row = val / NUM_COLS;
			int col = val % NUM_COLS;

			if (row % 2 != 0) {
				col = NUM_COLS - col - 1;
			}

			matrix[row][col] = new Cell(cellNum);
		}

		// create 5 snakes
		// 99 - 4
		snakes = new Snake[NUM_SNAKES];
		snakes[0] = new Snake(99, 4);
		getCell(99).setSnake(new Snake(0, 99)); // set start of snake
		getCell(4).setSnake(new Snake(-1, 4)); // set end of snake
		

		snakes[1] = new Snake(34, 8);
		getCell(34).setSnake(new Snake(0, 34));
		getCell(8).setSnake(new Snake(-1, 8));
		
		snakes[2] = new Snake(68, 24);
		getCell(68).setSnake(new Snake(0, 68));
		getCell(24).setSnake(new Snake(-1, 24));

		
		  snakes[3] = new Snake(72, 20); 
		  getCell(72).setSnake(new Snake(0,72));
		  getCell(24).setSnake(new Snake(-1, 20));
		  
		 snakes[4] = new Snake(45, 5); 
		 getCell(45).setSnake(new Snake(0,45));
		 getCell(5).setSnake(new Snake(-1, 5));
		 


		// create 5 ladders
		ladders = new Ladder[NUM_LADDERS];
		ladders[0] = new Ladder(33, 7);
		getCell(7).setLadder(new Ladder(7, 0)); // set end of ladder
		getCell(33).setLadder(new Ladder(33, -1)); // set start of ladder

		ladders[1] = new Ladder(95, 58);
		getCell(58).setLadder(new Ladder(58, 0));
		getCell(95).setLadder(new Ladder(95, -1));

		ladders[2] = new Ladder(75, 38);
		getCell(38).setLadder(new Ladder(38, 0));
		getCell(75).setLadder(new Ladder(75, -1));

		ladders[3] = new Ladder(50, 3);
		getCell(50).setLadder(new Ladder(50, -1));
		getCell(3).setLadder(new Ladder(3, 0));

		ladders[4] = new Ladder(51, 2);
		getCell(51).setLadder(new Ladder(51, -1));
		getCell(2).setLadder(new Ladder(2, 0));

	}
	// method whihc returns the row and column of the cell
	public Cell getCell(int cellNum) {
		int val = NUM_CELLS - cellNum;
		int row = val / NUM_COLS;
		int col = val % NUM_COLS;

		if (row % 2 != 0) {
			col = NUM_COLS - col - 1;
		}

		if (row * NUM_COLS == val && row != 0)
			row = row - 1;

		return matrix[row][col];
	}

	// return the name of the winner
	public String play() {
		int count = 0;

		boolean gameOver = false;
		Dice dice = new Dice();

		while (!gameOver) {

			// TODO: loop through each player in turn
			// Remember that a player than have more than one turn
			// before the next player has a turn
			for (; currPlayer < numPlayers;) {
				int step = dice.roll();

				Player player = players[currPlayer];
				// *** START OF LOOP BODY
				// TODO: current player rolls the dice

				// If player is not active
				if (player.isActive() == false) {
					// if dice is 6
					if (step == 6) {
						// Set the player to Active
						player.setActive(true);
					} else
						currPlayer++;
				} else {
					// before moving
					if (player.getCurPos().getNumber() + step <= 100
							&& getCell(player.getCurPos().getNumber() + step).getTemp() == true) {
						getCell(player.getCurPos().getNumber()).setTemp(false);
						gameOver = player.move(step);
						getCell(player.getCurPos().getNumber()).setTemp(false);
						System.out.println(player.getName() + ": " + player.getCurPos().getNumber());
						if (gameOver == false) {
							// check new position is start of snake or end of
							// ladder
							if (getCell(player.getCurPos().getNumber()).draw().contains("S1")) {// Start
																								// of
																								// snake
								System.out
										.println(player.getName() + ": before jump: " + player.getCurPos().getNumber());
								getCell(player.getCurPos().getNumber()).setTemp(true);
								player.getCurPos().setNumber(getEndOfSnake(player.getCurPos().getNumber()));
								getCell(player.getCurPos().getNumber()).setTemp(false);
								System.out
										.println(player.getName() + ": after jump: " + player.getCurPos().getNumber());
							} else if (getCell(player.getCurPos().getNumber()).draw().contains("L2")) { // End
																										// of
																										// ladder
								System.out
										.println(player.getName() + ": before jump: " + player.getCurPos().getNumber());
								getCell(player.getCurPos().getNumber()).setTemp(true);
								player.getCurPos().setNumber(getStartOfLadder(player.getCurPos().getNumber()));
								getCell(player.getCurPos().getNumber()).setTemp(false);
								System.out
										.println(player.getName() + ": after jump: " + player.getCurPos().getNumber());
							}

							// Draw the board
							drawBoard();
						} else {
							drawBoard();
							System.out.println("Winner is: " + player.getName());

							return player.getName();
						}
					}
					// Check to change player
					if (step != 6)
						currPlayer++;
				}
				

				// *** END OF LOOP BODY
			}
			if (currPlayer >= numPlayers) // reset new turn player
				currPlayer = 0;
		}
		return null;
		// TODO: return name of the winner
	}
	// method which is used to draw board on the screen : kind of formatting are used
	private void drawBoard() {

		// draw a line on top using dashes
		// ---------------------
		String pad;
		for (Cell[] row : matrix) {
			for (Cell col : row) {
				pad = "  ";
				for (Player p : players) {
					if (p.getCurPos().getNumber() == col.getNumber())
						pad = p.getName();
				}
				System.out.print(col.draw() + pad + "|");
			}

			System.out.println();
		}
		System.out.println();
		// draw a line at the bottom using dashes
		// ---------------------
	}
	// returns the end of snake 
	public int getEndOfSnake(int pos) {
		for (Snake s : snakes) {
			if (s.getStart() == pos) {
				System.out.println(s.getEnd() + "XXX");
				return s.getEnd();
			}
		}
		return -1;
	}
	// returns the start of ladder
	public int getStartOfLadder(int pos) {
		for (Ladder l : ladders) {
			if (l.getEnd() == pos) {
				System.out.println(l.getStart() + "XXX");
				return l.getStart();
			}
		}
		return -1;
	}
}
