//Dice is the class which uses a method called roll whenever the player rools the dice
import java.util.Random;

public class Dice 
{
	//declaring constants
	static final int MAX_VAL = 6;
	static final int MIN_VAL = 1;
	//creating the instance of random class
	private Random rand = new Random();
	//roll method which returns a random number
	public int roll() {
		return MIN_VAL + rand.nextInt(MAX_VAL - MIN_VAL + 1);
	}
}
