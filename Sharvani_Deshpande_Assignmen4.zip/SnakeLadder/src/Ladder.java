// Class which has all the instances for the Ladder 
public class Ladder {
	private int start = -1;
	private int end = -1;
	//constructor
	public Ladder(int start, int end) {
		this.start = start;
		this.end = end;
	}
	//returns the start
	public int getStart() {
		return start;
	}
	// returns the end
	public int getEnd() {
		return end;
	}
}
