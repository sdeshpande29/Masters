//Snake class will have all the instances and methods that a snake can have
public class Snake {
	private int start = -1;
	private int end = -1;
	// constructor
	public Snake(int start, int end) {
		this.start = start;
		this.end = end;
	}
	// return the start of the snake
	public int getStart() {
		return start;
	}
	// returns the end of the snake 
	public int getEnd() {
		return end;
	}
}
