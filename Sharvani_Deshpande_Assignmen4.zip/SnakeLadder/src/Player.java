//Player class has all the instances for the player
public class Player {
	private String name = "";
	private Cell currentPosition = null;
	private boolean active = false;
	//parameterized constructor
	public Player(String name) {
		currentPosition = new Cell(0);
		this.name = name;
	}
	//sets the current position
	public void setCurPos(Cell currentPosition) {
		this.currentPosition = currentPosition;
	}
	//returns the current position
	public Cell getCurPos() {
		return currentPosition;
	}
	
	// returns active state
	public boolean isActive() {
		return active;
	}
	//sets the active state
	public void setActive(boolean active) {
		this.active = active;
	}
	
	// get player name
	public String getName(){
		return name;
	}
	// method to move the player
	public boolean move(int step) {
		int newPos = currentPosition.getNumber() + step;

		if(newPos >= 100) {
			System.out.println("Actual pos is: " + newPos);
			currentPosition.setNumber(100);
			return true;
		}
		else {
			currentPosition.setNumber(newPos);
			return false;
		}
	}
}
