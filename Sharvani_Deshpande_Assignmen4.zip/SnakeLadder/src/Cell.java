//This class is used to intialise all the getters and setters for the Cell instances 
public class Cell 
{
	
	private int number = 0;
	private Snake snake;
	private Ladder ladder;
	private boolean temp;
	//constructor
	public Cell(int number) {
		this.number = number;
		temp = true;
	}	

	// method returns a number
	public int getNumber() {
		return number;
	}
	//method sets the number
	public void setNumber(int number) {
		this.number = number;
	}

	// method sets the snake
	public void setSnake(Snake snake) {
		this.snake = snake;
	}
	//method returns the snake
	public Snake getSnake() {
		return snake;
	}

	// method sets the ladder
	public void setLadder(Ladder ladder) {
		this.ladder = ladder;
	}
	//method returns the ladder
	public Ladder getLadder() {
		return ladder;
	}
	//methdo returns the temp
	public boolean getTemp() {
		return temp;
	}
	//method sets the temp
	public void setTemp(boolean temp) {
		this.temp = temp;
	}


	//draw method to fill the cells 
	public String draw() {
		String data = String.format("%03d", number) + "";
		// cell contains ladder
		if(ladder != null) {
			if(ladder.getEnd() == 0)
				data += "L2";
			else
				data += "L1";
		}
		else
			data += "  ";

		if(snake != null) {
			if(snake.getStart() == 0)
				data += "S1";
			else
				data += "S2";
		}
		else
			data += "  ";

		return data;
	}

}
