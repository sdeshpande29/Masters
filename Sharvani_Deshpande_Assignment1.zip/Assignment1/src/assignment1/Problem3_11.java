//Name : Sharvani Deshpande
//Programming Assignment 1
//Solution for Problem 3.11
//Submitted for CS585C, Fall 2016
//Due Date: 09/30/2016

package assignment1;

import java.util.Scanner;
//This program is used to print number of days in a month where month and year are given as inputs
public class Problem3_11 
{
//Main method To print the number of days 
	public static void main(String[] args) 
	{
		
		// TODO Auto-generated method stub
		//Scanner instance to take the input from the console
		 Scanner s = new Scanner(System.in);
		 //month represents the value entered by the user : integer which stores the month number
		 //Similarly year represents an integer value which also stores the year data
		  int month, year;
		  //isLeapYear is a boolean value which stores either True or False by checking if its a leap year
		  //If the year entered is leap then True is stores else False is stored
		  boolean isLeapYear;
		  //Prompt the user to enter the month value
		  System.out.print("Enter a number for the month (1 for Januaray, 2 for February .... 12 for December):");
		  month = s.nextInt();
		  //prompt the user to enter the year 
		  System.out.print("Enter a number for the year:");
		  year = s.nextInt();
		  //isLeapYear is a boolean variable which says if the year is leap or not
		  // A leap year is divisible by 4  but not by 100  or divisible by 400
		  isLeapYear = (year % 4 == 0 && year % 100 != 0) || (year % 100 == 0);
		  //switch statement to print the number of days based on value of the month each case is defined
		  switch(month)
		  {
			  case 1: System.out.println("January "+ year + " has 31 days");
			  			break;
			  			
			  case 2:if(isLeapYear)
	  					{
		  					System.out.print("February " + year + " has 29 days.");
		  					break;
	  					} 
	  				else
	  					{
	  						System.out.print("February " + year + " has 28 days.");
	  						break;
	  					} 
				  
			  case 3 :System.out.print("March " + year + " has 31 days.");
			  			break;
			  case 4: System.out.print("April " + year + " has 30 days.");
			  			break;
			  case 5 :System.out.print("May " + year + " has 31 days.");
			  			break;
			  case 6: System.out.print("June " + year + " has 30 days.");
			  			break;
				  
			  case 7: System.out.print("July " + year + " has 31 days.");;
			  			break;
			  case 8: System.out.print("August " + year + " has 31 days.");
			  			break;
			  case 9: System.out.print("September " + year + " has 30 days.");
			  			break;
				  
			  case 10:  System.out.print("October " + year + " has 31 days.");
			  			break;
			  case 11 : System.out.print("November " + year + " has 30 days.");
			  			break;
			  case 12 :   System.out.print("December " + year + " has 31 days.");
			  break;
			  default: 	//do nothing
				  		break;
		  

}
s.close();
}
	}

/*
 ====================
 Sample Output:
 ====================
 Enter a number for the month (1 for January, 2 for February .... 12 for December):4
Enter a number for the year:2016
April 2016 has 30 days.

====================
Sample Output:
====================
Enter a number for the month (1 for January, 2 for February .... 12 for December): 2
Enter a number for the year:2015
February 2015 has 28 days.
 */
