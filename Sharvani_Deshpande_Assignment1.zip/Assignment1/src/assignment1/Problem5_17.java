//Name : Sharvani Deshpande
//Programming Assignment 1
//Solution for Problem 3.11
//Submitted for CS585C, Fall 2016
//Due Date : 09/30/2016

package assignment1;
import java.util.*;
 //create a class Problem5_17 to print the pyramid with n number of lines given as input
public class Problem5_17 
{
	//main method to print the pyramid
    public static void main(String[] args)
    {
    	//create a scanner
        Scanner sb = new Scanner(System.in);
         //Prompt the user to enter number of lines
        System.out.println("Enter the number of lines: ");
        int number = sb.nextInt();
        String str = "                                      ";
         int i=1;
         //printing the numbers using format specifiers
         while(i<=number)
         {
        	 System.out.print(str);
        	 for(int s=i;s>=1;s--)
        	 {
        		 System.out.printf(" %1d",s);
        	 }
        	 for (int l=2;l<=i;l++)
        	 {
        		System.out.printf(" %1d",l); 
        	 }
        	 System.out.println();
             str = str.substring(2);
        	 i++;
         }
         //closing the scanner object
    sb.close();          
    } 
    
}
/*
 ==================
 Sample Output:
 ==================
 Enter the number of lines: 
3
                                       1
                                     2 1 2
                                   3 2 1 2 3
 */
