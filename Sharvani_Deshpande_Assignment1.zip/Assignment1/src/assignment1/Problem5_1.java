//Name : Sharvani Deshpande
//Programming Assignment 1
//Solution for Problem 3.11
//Submitted for CS585C, Fall 2016

package assignment1;

import java.util.Scanner;
public class Problem5_1 
{
	// Main method to define actual functionality
	public static void main(String args[])
	{
		//initializing scanner to take the input from the screen
		Scanner inp = new Scanner(System.in);
		// pCount holds the number of variables which are positive
		//nCount holds number of variables which are negative
		//total represents an integer which is the sum of all the numbers entered
		//count represents number of values entered
		int pCount=0, nCount=0, total =0 , count=0;
		//average represents the variable which is used to hold the value of average of all the numbers
		double average=0.0;
		int number;
		System.out.println("Enter the number: ");
	   
	     while((number=inp.nextInt())!=0)
	     {
	     total = total+number;
	     count++;
	     //if number is positive
	     if(number>0)
	     {
	    	 pCount++;
	     }
	     // else it would be negative
	     else
	     {
	    	 nCount++;
	     }
	     }
	     
	     //calculating average
	     average=total/count;
	     //Printing all the information
	     System.out.println("positive numbers count is " +pCount);
	     System.out.println("negative numbers count is " +nCount);
	     System.out.println("Total Count is " +count);
	     System.out.println("Sum of all the numbers is " +total);
	     System.out.println("Average of all the numbers is "  +average);
	     //Scanner object is closed
	     inp.close();
	     }
	}

/*
 ====================
 Sample Output:
 ====================
 Enter the number: 
4 5 6 0
positive numbers count is 3
negative numbers count is 0
Total Count is 3
Sum of all the numbers is 15
Average of all the numbers is 5.0

================
Sample Output:
================
Enter the number: 
2 3 -2 -3 4 9 -5 -7 0
positive numbers count is 4
negative numbers count is 4
Total Count is 8
Sum of all the numbers is 1
Average of all the numbers is 0.0
  */
