/*
BHL: Get in the habit of using the array length in methods so your code does not depend on the
specific count you hardcoded.
*/

/**
 	Name : Sharvani Deshpande
	Programming Assignment 2
	Solution for Problem 7.11
	Submitted for CS585C, Fall 2016
	Due Date: 10/14/2016 */
import java.util.Scanner;

/**
 * @author SHARVANI DESHPANDE
 * This class is used to take the input
 *  of 10 numbers and calculate its  mean 
 *  and standard deviation
 */
public class Problem7_11 {
	/* Main method*/
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Scanner inp = new Scanner(System.in);
		double a[]=new double[10];
		double sum=0,mean=0;
		//prompt the user to enter the input values
		System.out.println("Enter 10 numbers");
		for(int i=0;i<10;i++)
		{
			a[i]=inp.nextDouble();

		}
		mean=mean(a);
		//print the mean value
		System.out.println("mean is "+mean);
		double[] temp= new double[10];
		for(int i=0;i<10;i++)
		{
			temp[i]=a[i]-mean;
		}
		// print the standard deviation
		double dev=deviation(temp);
		System.out.println("Standard deviation for the given set of numbers is"+dev);


	}
	/** compute the deviation of double values**/
	public static double deviation(double[] x)
	{
		double meanTemp=0;
		double sumTemp=0;
		for(int i=0;i<10;i++)
		{
			x[i]=Math.pow(x[i], 2);
			sumTemp+=x[i];
		}

		meanTemp=sumTemp/9;
		double deviation=Math.sqrt(meanTemp);
		return deviation;

	}
	/** compute the mean of an array  of double values**/
	public static double mean( double[] x)
	{
		double y=0;
		for(int i=0; i<10;i++)
		{
			y=y+x[i];
		}
		y=y/10;


		return y;

	}

}
