/*
BHL: Try to simplify blocks like:
			if (sum != 1) 
			{
				temp = false;
			}
			else
			{
				temp= true;
			}
into one line like:
			temp = (sum == 1);
*/

/**
 	Name : Sharvani Deshpande
	Programming Assignment 2
	Solution for Problem 8.25
	Submitted for CS585C, Fall 2016
	Due Date: 10/14/2016 */
import java.util.Scanner;
	/*This class is used to determine if a matrix which is taken 
	 * as an input from the use is Markov Matrix 
	 */
public class Problem8_25 {

	public static void main(String[] args) 
	{
		// two dimensional array to hold the input values
		double[][] mat = new double[3][3];

		Scanner input = new Scanner(System.in);
		// taking input from the user
		System.out.println("Enter a 3-by-3 matrix row by row: ");
		for (int i = 0; i < mat.length; i++)
		{
			for (int j = 0; j < mat[i].length; j++)
			{
				mat[i][j] = input.nextDouble();
			}
		}

		// printing the result
		System.out.println(isMarkovMatrix(mat) ? "The matrix is positive Markov" : "The matrix is not positive Markov.");
	}
	/*
	 * Method to check if the given input array is a markov matrix or not
	 * This will return true if it is a matkov matrix
	 * else it will return false
	 */
	public static boolean isMarkovMatrix(double[][] s) {
		boolean temp = false;

		for (int j = 0; j < s[0].length; j++) 
		{
			double sum = 0;

			for (int i = 0; i < s.length; i++) 
			{

				double number = s[i][j];
				if (number < 0) 
				{
					temp = false;
				}
				else
				{
					temp=true;
				}
				sum += number;
			}
			if (sum != 1) 
			{
				temp = false;
			}
			else
			{
				temp= true;
			}
		}
		return temp;
	}
}

/*
 ==========================
 Output:
 ==========================
 Enter a 3-by-3 matrix row by row: 
0.15 0.875 0.375
0.55 0.005 0.225
0.30 0.12 0.4
The matrix is positive Markov
 ==========================
 Output:
 ==========================
 Enter a 3-by-3 matrix row by row: 
0.95 -0.875 0.375
0.65 0.005 0.225
0.30 0.22 -0.4
The matrix is not positive Markov.
 *
 */
