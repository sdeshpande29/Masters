/*  Name : Sharvani Deshpande
 * 	Programming Assignment 5
 * 	Java Layout Assignment Design
 * 	Due Date : 12/02/2016
 * 	Submitted for CS585C , Fall 2016 */


import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.paint.Color;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import javafx.stage.Stage;
import javafx.scene.layout.FlowPane;

public class Homework5 extends Application 
{
	//CREATING BUTTONS, TEXT BOXES AND LEFT AND RIGHT PANES
    HBox rbuttons= new HBox();
    HBox buttons = new HBox();
    VBox leftPane= new VBox();
    VBox textboxes= new VBox();
    VBox rightPane = new VBox();
    //CREATING LABELS
    Label clabel1 = new Label("Denmark");
    Label clabel2 = new Label("Germany");
    Label clabel3 = new Label("China");
    Label clabel4 = new Label("India");
    Label clabel5 = new Label("Norway");
    Label clabel6 = new Label("United Kinngdom");
    //CREATING IMAGES
    ImageView fImage1 = new ImageView("image/flagIcon0.gif");
    ImageView fImage2 = new ImageView("image/flagIcon1.gif");
    ImageView fImage3 = new ImageView("image/flagIcon2.gif");
    ImageView fImage4 = new ImageView("image/flagIcon3.gif");
    ImageView fImage5 = new ImageView("image/flagIcon4.gif");
    ImageView fImage6 = new ImageView("image/flagIcon5.gif");

    @Override
    public void start(Stage stage) throws Exception {
        BorderPane borderPande = new BorderPane();
        //IMPLEMENTING RADIO BUTTONS
        RadioButton radioButtons1 = new RadioButton();
        RadioButton radioButtons2 = new RadioButton();
        RadioButton radioButtons3 = new RadioButton();
        RadioButton radioButtons4 = new RadioButton();
        radioButtons1.setText("Flag 1");
        radioButtons2.setText("Flag 2");
        radioButtons3.setText("Flag 3");
        radioButtons4.setText("Flag 4");
        radioButtons1.setSelected(true);
        ToggleGroup rbSet = new ToggleGroup();
        rbSet.getToggles().addAll(radioButtons1,radioButtons2,radioButtons3,radioButtons4);
        rbuttons.getChildren().addAll(radioButtons1,radioButtons2,radioButtons3,radioButtons4);
        rbuttons.setAlignment(Pos.CENTER);
        rbuttons.setPadding(new Insets(10, 0, 0, 0));
        rbuttons.setSpacing(10);
        rbuttons.setStyle("-fx-border-color:black;");
        //IMPLEMENTING IMAGES AND LABELS ON THE LEFT SIDE
        HBox[] Pane = new HBox[6];
        leftPane = new VBox();
        Pane[0]= new HBox();
        Pane[1]= new HBox();
        Pane[2]= new HBox();
        Pane[0].getChildren().addAll(fImage1, clabel1);
        Pane[0].setAlignment(Pos.BASELINE_LEFT);
        leftPane.getChildren().add(Pane[0]);
        Pane[1].getChildren().addAll(fImage2, clabel2);
        Pane[1].setAlignment(Pos.BASELINE_LEFT);
        leftPane.getChildren().add(Pane[1]);
        Pane[2].getChildren().addAll(fImage3, clabel3);
        Pane[2].setAlignment(Pos.BASELINE_LEFT);
        leftPane.getChildren().add(Pane[2]);
        leftPane.setAlignment(Pos.CENTER);
        leftPane.setSpacing(60);
        textboxes = new VBox();
        //IMPLEMENTING THE TEXT FIELDS
        TextField[] textFields = new TextField[9];
        String text = "Display Line ";
        for (int i = 0; i < 9; i++) {
            textFields[i] = new TextField(text + (i + 1));
            textFields[i].setPrefColumnCount(40);
            textFields[i].setBackground(new Background(new BackgroundFill(Color.YELLOW, null, null)));
            textFields[i].setStyle("-fx-text-fill:blue;-fx-font-family:sans-serif;-fx-font-weight:bold;-fx-font-style:italic;");
        }
        textboxes.getChildren().addAll(textFields);
        textboxes.setSpacing(2);
        rightPane = new VBox();
        //IMPLEMENTING THE IMAGES AND LABELS ON THE RIGHT SIDE
        Pane[3]= new HBox();
        Pane[4]= new HBox();
        Pane[5]= new HBox();
        Pane[3].getChildren().addAll(fImage4, clabel4);
        Pane[3].setAlignment(Pos.BASELINE_RIGHT);
        rightPane.getChildren().add(Pane[3]);
        Pane[4].getChildren().addAll(fImage5, clabel5);
        Pane[4].setAlignment(Pos.BASELINE_RIGHT);
        rightPane.getChildren().add(Pane[4]);
        Pane[5].getChildren().addAll(fImage6, clabel6);
        Pane[5].setAlignment(Pos.BASELINE_RIGHT);
        rightPane.getChildren().addAll(Pane[5]);
        rightPane.setAlignment(Pos.CENTER);
        rightPane.setSpacing(60);
        Button buttonHelp = new Button("Help");
    	Button buttonCancel = new Button("Cancel");
    	Button buttonOk = new Button("Ok");
        buttons = new HBox();
        buttons.getChildren().addAll(buttonHelp,buttonCancel,buttonOk);
        buttons.setAlignment(Pos.BASELINE_RIGHT);
        buttons.setPadding(new Insets(5, 0, 0, 0));
        buttons.setSpacing(5);
        FlowPane pane = new FlowPane();
        pane.setAlignment(Pos.BASELINE_CENTER);
        pane.getChildren().add(rbuttons);
        borderPande.setTop(pane);
        borderPande.setStyle("-fx-background-color: CAC3C1;");
        borderPande.setLeft(leftPane);
        borderPande.setCenter(textboxes);
        borderPande.setRight(rightPane);
        borderPande.setBottom(buttons);
        Scene scene = new Scene(borderPande);
        stage.setTitle("Assignment 5!!");
        stage.setScene(scene);
        stage.show();

    }

    public static void main(String[] args) {
        Application.launch(args);
    }
}